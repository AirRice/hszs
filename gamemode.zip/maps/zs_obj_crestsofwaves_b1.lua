hook.Add("InitPostEntityMap", "Adding", function()
	GAMEMODE.ZombieDamageMultiplier = 2.5
end)
